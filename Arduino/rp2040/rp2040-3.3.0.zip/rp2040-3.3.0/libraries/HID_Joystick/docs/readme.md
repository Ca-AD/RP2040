# Joystick library

The Joystick functions enable a RP2040 board to act as a HID game controller.

To use this library:

```
#include <Joystick.h>
```


## Examples

* [Joystick-AllFunctions] Includes example calls for each Joystick function
