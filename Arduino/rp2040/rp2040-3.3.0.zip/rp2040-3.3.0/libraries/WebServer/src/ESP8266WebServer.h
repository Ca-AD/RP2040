// Since things may just work, we'll redirect for now
#include "WebServer.h"

using ESP8266WebServer = WebServer;
