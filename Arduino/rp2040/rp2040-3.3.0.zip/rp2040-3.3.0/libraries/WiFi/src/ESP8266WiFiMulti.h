// Since things may just work, we'll redirect for now
#include "WiFiMulti.h"

using ESP8266WiFiMulti = WiFiMulti;
