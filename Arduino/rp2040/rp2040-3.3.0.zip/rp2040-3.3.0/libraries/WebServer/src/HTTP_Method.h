#pragma once

#include "http_parser.h"

typedef enum http_method HTTPMethod;
#define HTTP_ANY (HTTPMethod)(255)
