#ifdef ENABLE_CLASSIC
#include "PicoBluetoothHID.h"
#endif

#ifdef ENABLE_BLE
#include "PicoBluetoothBLEHID.h"
#endif
