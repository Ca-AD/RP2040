#pragma once

// This is a bare board with no real predefined pins, so use generic

#include "../generic/pins_arduino.h"
