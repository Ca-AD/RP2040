// Since things may just work, we'll redirect for now
#include "WiFi.h"
